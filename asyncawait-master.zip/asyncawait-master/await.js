﻿var await = require('./src/await');
module.exports = await;
