﻿var async = require('./src/async');
var await = require('./src/await');

exports.async = async;
exports.await = await;
