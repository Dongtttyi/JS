﻿var async = require('./src/async');
module.exports = async;
