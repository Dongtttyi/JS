﻿import types = require('./src/types');
export = types.await;
